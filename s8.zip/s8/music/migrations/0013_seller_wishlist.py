# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('music', '0012_auto_20181010_1551'),
    ]

    operations = [
        migrations.AddField(
            model_name='seller',
            name='wishlist',
            field=models.BooleanField(default=False),
        ),
    ]
